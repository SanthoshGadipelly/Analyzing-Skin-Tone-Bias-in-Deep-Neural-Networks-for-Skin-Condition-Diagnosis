#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.inception_v3 import InceptionV3
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model


# In[2]:


# Load the dataset
data = pd.read_csv("final_dataset.csv")


# In[3]:


# Define the image data generator with augmentation (optional)
train_datagen = ImageDataGenerator(
    rescale=1./255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True
)

test_datagen = ImageDataGenerator(rescale=1./255)


# In[4]:


# Split the data into training and testing sets with an 80:20 ratio
train_data = data.sample(frac=0.8, random_state=42)
test_data = data.drop(train_data.index)


# In[5]:


# Define the input image size and batch size
img_size = (224, 224)
batch_size = 32


# In[6]:


# Create the generators for training and testing data
train_generator = train_datagen.flow_from_dataframe(
    dataframe=train_data,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=img_size,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
)

test_generator = test_datagen.flow_from_dataframe(
    dataframe=test_data,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=img_size,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
)


# In[7]:


# Define the InceptionNet model and load pre-trained weights
base_model = InceptionV3(weights='imagenet', include_top=False)


# In[8]:


# Add a global spatial average pooling layer
x = base_model.output
x = GlobalAveragePooling2D()(x)


# In[9]:


# Add a fully-connected layer with 1024 neurons
x = Dense(1024, activation='relu')(x)


# In[10]:


# Add a final output layer with one neuron per class
predictions = Dense(len(train_generator.class_indices), activation='softmax')(x)


# In[11]:


# Create the final model
model = Model(inputs=base_model.input, outputs=predictions)


# In[12]:


# Freeze all layers in the base model for transfer learning
for layer in base_model.layers:
    layer.trainable = False


# In[13]:


# Compile the model with categorical cross-entropy loss and Adam optimizer
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


# In[14]:


# Train the model on the training data
history = model.fit(train_generator, epochs=20, validation_data=test_generator)


# In[15]:


# Evaluate the model on the testing data
test_loss, test_acc = model.evaluate(test_generator)
print("Test accuracy:", test_acc)


# In[16]:


print('Test accuracy: {:.2f}%'.format(test_acc * 100))


# In[18]:


#accuracies by each FST
validation_probabilities = model.predict(test_generator)
predicted_labels = np.argmax(validation_probabilities, axis=1)

true_labels = np.array(test_generator.classes)
fitzpatrick_scale_values = np.array(df.loc[test_generator.index_array, 'fitzpatrick_scale'])


# In[19]:


def calculate_accuracy_by_fitzpatrick_scale(predictions, true_labels, fitzpatrick_scale_values):
    accuracies = {}
    for scale_value in np.unique(fitzpatrick_scale_values):
        indices = np.where(fitzpatrick_scale_values == scale_value)
        scale_true_labels = true_labels[indices]
        scale_predictions = predictions[indices]
        correct_predictions = np.sum(scale_true_labels == scale_predictions)
        accuracy = correct_predictions / len(scale_true_labels)
        accuracies[scale_value] = accuracy
    return accuracies


# In[22]:


accuracies_by_fitzpatrick_scale = calculate_accuracy_by_fitzpatrick_scale(predicted_labels, true_labels, fitzpatrick_scale_values)


# In[ ]:


for scale_value, accuracy in accuracies_by_fitzpatrick_scale.items():
    print(f"Accuracy for Fitzpatrick scale {scale_value}: {accuracy:.4f}")

