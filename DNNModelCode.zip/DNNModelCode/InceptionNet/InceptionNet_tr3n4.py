#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.inception_v3 import InceptionV3
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model

# Load the dataset
data = pd.read_csv("final_dataset.csv")

# Filter data for training with fitzpatrick_scale values 3 and 4
train_data = data[data['fitzpatrick_scale'].isin([3, 4])]

# Filter data for testing with fitzpatrick_scale values 1, 2, 5, and 6
test_data = data[data['fitzpatrick_scale'].isin([1, 2, 5, 6])]

# Define the image data generator with augmentation (optional)
train_datagen = ImageDataGenerator(
    rescale=1./255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True
)

test_datagen = ImageDataGenerator(rescale=1./255)

# Define the input image size and batch size
img_size = (224, 224)
batch_size = 32

# Create the generators for training and testing data
train_generator = train_datagen.flow_from_dataframe(
    dataframe=train_data,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=img_size,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
)

test_generator = test_datagen.flow_from_dataframe(
    dataframe=test_data,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=img_size,
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False,
)

# Define the InceptionNet model and load pre-trained weights
base_model = InceptionV3(weights='imagenet', include_top=False)

# Add a global spatial average pooling layer
x = base_model.output
x = GlobalAveragePooling2D()(x)

# Add a fully-connected layer with 1024 neurons
x = Dense(1024, activation='relu')(x)

# Add a final output layer with one neuron per class
predictions = Dense(len(train_generator.class_indices), activation='softmax')(x)

# Create the final model
model = Model(inputs=base_model.input, outputs=predictions)

# Freeze all layers in the base model for transfer learning
for layer in base_model.layers:
    layer.trainable = False

# Compile the model with categorical cross-entropy loss and Adam optimizer
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train the model on the training data
history = model.fit(train_generator, epochs=20, validation_data=test_generator)

# Evaluate the model on the testing data
test_loss, test_acc = model.evaluate(test_generator)
print("Test accuracy:", test_acc)


# In[2]:


print("Testing accuracy: {:.2f}%".format(test_acc * 100))


# In[6]:


validation_probabilities = model.predict(test_generator)
predicted_labels = np.argmax(validation_probabilities, axis=1)
true_labels = np.array(test_generator.classes)
fitzpatrick_scale_values = np.array(test_df.loc[test_generator.index_array, 'fitzpatrick_scale'])

def calculate_accuracy_by_fitzpatrick_scale(predictions, true_labels, fitzpatrick_scale_values):
    accuracies = {}
    for scale_value in np.unique(fitzpatrick_scale_values):
        indices = np.where(fitzpatrick_scale_values == scale_value)
        scale_true_labels = true_labels[indices]
        scale_predictions = predictions[indices]
        correct_predictions = np.sum(scale_true_labels == scale_predictions)
        accuracy = correct_predictions / len(scale_true_labels)
        accuracies[scale_value] = accuracy
    return accuracies

accuracies_by_fitzpatrick_scale = calculate_accuracy_by_fitzpatrick_scale(predicted_labels, true_labels, fitzpatrick_scale_values)

for scale_value, accuracy in accuracies_by_fitzpatrick_scale.items():
    print(f"Accuracy for Fitzpatrick scale {scale_value}: {accuracy:.4f}")


# In[7]:





# In[8]:





# In[ ]:




