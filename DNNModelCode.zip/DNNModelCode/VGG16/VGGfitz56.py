#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator


# In[ ]:


df = pd.read_csv('final_dataset.csv')


# In[ ]:


IMAGE_SIZE = (224, 224)
BATCH_SIZE = 32
NUM_CLASSES = 110
EPOCHS = 20
RANDOM_SEED = 42


# In[ ]:


train_df = df[df['fitzpatrick_scale'].isin([5, 6])]
test_df = df[df['fitzpatrick_scale'].isin([1, 2, 3, 4])]


# In[ ]:


train_datagen = ImageDataGenerator(
    rescale=1./255,
    horizontal_flip=True,
    rotation_range=20,
    shear_range=0.2,
    zoom_range=0.2,
)

test_datagen = ImageDataGenerator(rescale=1./255)

train_generator = train_datagen.flow_from_dataframe(
    dataframe=train_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    seed=RANDOM_SEED
)

test_generator = test_datagen.flow_from_dataframe(
    dataframe=test_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=IMAGE_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    seed=RANDOM_SEED
)


# In[ ]:


model = tf.keras.models.Sequential([
    tf.keras.applications.VGG16(
        include_top=False,
        weights='imagenet',
        input_shape=(224, 224, 3),
    ),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(1024, activation='relu'),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(NUM_CLASSES, activation='softmax')
])


# In[ ]:


model.compile(
    loss='categorical_crossentropy',
    optimizer=tf.keras.optimizers.Adam(learning_rate=1e-5),
    metrics=['accuracy']
)


# In[ ]:


model.fit(
    train_generator,
    validation_data=test_generator,
    epochs=EPOCHS
)


# In[ ]:


test_loss, test_acc = model.evaluate(test_generator)
print('Test accuracy:', test_acc)


# In[ ]:


validation_probabilities = model.predict(test_generator)
predicted_labels = np.argmax(validation_probabilities, axis=1)


# In[ ]:


true_labels = np.array(test_generator.classes)
fitzpatrick_scale_values = np.array(test_df.loc[test_generator.index_array, 'fitzpatrick_scale'])


# In[ ]:


def calculate_accuracy_by_fitzpatrick_scale(predictions, true_labels, fitzpatrick_scale_values):
    accuracies = {}
    for scale_value in np.unique(fitzpatrick_scale_values):
        indices = np.where(fitzpatrick_scale_values == scale_value)
        scale_true_labels = true_labels[indices]
        scale_predictions = predictions[indices]
        correct_predictions = np.sum(scale_true_labels == scale_predictions)
        accuracy = correct_predictions / len(scale_true_labels)
        accuracies[scale_value] = accuracy
    return accuracies


# In[ ]:


accuracies_by_fitzpatrick_scale = calculate_accuracy_by_fitzpatrick_scale(predicted_labels, true_labels, fitzpatrick_scale_values)


# In[ ]:


for scale_value, accuracy in accuracies_by_fitzpatrick_scale.items():
    print(f"Accuracy for Fitzpatrick scale {scale_value}: {accuracy:.4f}")

