#!/usr/bin/env python
# coding: utf-8

# # Training on 3,4. Testing on 1,2,5,6

# In[2]:


import pandas as pd
import numpy as np
import os
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications.densenet import DenseNet121
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model
from sklearn.model_selection import train_test_split

# Load the dataset
df = pd.read_csv("final_dataset.csv")

# Set the input image size
img_width, img_height = 224, 224

# Set the batch size
batch_size = 32

# Split the dataset into training and testing sets
train_df = df[df["fitzpatrick_scale"].isin([3, 4])]
test_df = df[df["fitzpatrick_scale"].isin([1, 2, 5, 6])]

# Define the training and testing data generators
train_datagen = ImageDataGenerator(
    rescale=1./255,
    #horizontal_flip=True,
    #validation_split=0.2
)

test_datagen = ImageDataGenerator(
    rescale=1./255
)

train_generator = train_datagen.flow_from_dataframe(
    dataframe=train_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
    subset="training"
)
"""

validation_generator = train_datagen.flow_from_dataframe(
    dataframe=train_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=True,
    subset="validation"
)
"""
test_generator = test_datagen.flow_from_dataframe(
    dataframe=test_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=(img_width, img_height),
    batch_size=batch_size,
    class_mode="categorical",
    shuffle=False
)



# Build the model
base_model = DenseNet121(weights="imagenet", include_top=False, input_shape=(img_width, img_height, 3))

x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dense(1024, activation="relu")(x)
predictions = Dense(len(train_generator.class_indices), activation="softmax")(x)

model = Model(inputs=base_model.input, outputs=predictions)


# Freeze the layers in the base model
for layer in base_model.layers:
    layer.trainable = False
    
# Compile the model
model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])


# Train the model
model.fit(
    train_generator,
    epochs=20,
    validation_data=test_generator
)

# Evaluate the model on the testing set
loss, accuracy = model.evaluate(test_generator)
print("Testing accuracy: {:.2f}%".format(accuracy * 100))


# In[4]:


validation_probabilities = model.predict(test_generator)
predicted_labels = np.argmax(validation_probabilities, axis=1)


# In[5]:


true_labels = np.array(test_generator.classes)
fitzpatrick_scale_values = np.array(test_df.loc[test_generator.index_array, 'fitzpatrick_scale'])


# In[7]:


def calculate_accuracy_by_fitzpatrick_scale(predictions, true_labels, fitzpatrick_scale_values):
    accuracies = {}
    for scale_value in np.unique(fitzpatrick_scale_values):
        indices = np.where(fitzpatrick_scale_values == scale_value)
        scale_true_labels = true_labels[indices]
        scale_predictions = predictions[indices]
        correct_predictions = np.sum(scale_true_labels == scale_predictions)
        accuracy = correct_predictions / len(scale_true_labels)
        accuracies[scale_value] = accuracy
    return accuracies


# In[ ]:


accuracies_by_fitzpatrick_scale = calculate_accuracy_by_fitzpatrick_scale(predicted_labels, true_labels, fitzpatrick_scale_values)


# In[ ]:


for scale_value, accuracy in accuracies_by_fitzpatrick_scale.items():
    print(f"Accuracy for Fitzpatrick scale {scale_value}: {accuracy:.4f}")

