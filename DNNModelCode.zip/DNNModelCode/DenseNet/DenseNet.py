#!/usr/bin/env python
# coding: utf-8

# # DenseNet Random Model 80-20 split

# In[24]:


import pandas as pd
from sklearn.model_selection import train_test_split
from keras.preprocessing.image import ImageDataGenerator
from keras.models import Sequential
from keras.layers import Dense, Conv2D, MaxPooling2D, Dropout, Flatten
from keras.applications.densenet import DenseNet121

# Load dataset
df = pd.read_csv('final_dataset.csv')

# Split into train and test sets
train_df, test_df = train_test_split(df, test_size=0.2, random_state=42, stratify=df['label'])

# Create data generators
train_datagen = ImageDataGenerator(rescale=1./255, validation_split=0.2)
test_datagen = ImageDataGenerator(rescale=1./255)

train_generator = train_datagen.flow_from_dataframe(
    dataframe=train_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=(224, 224),
    batch_size=32,
    class_mode='categorical',
    subset='training'
)

validation_generator = train_datagen.flow_from_dataframe(
    dataframe=train_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=(224, 224),
    batch_size=32,
    class_mode='categorical',
    subset='validation'
)

test_generator = test_datagen.flow_from_dataframe(
    dataframe=test_df,
    directory=None,
    x_col="local_filename",
    y_col="label",
    target_size=(224, 224),
    batch_size=32,
    class_mode='categorical'
)

# Create model
model = Sequential()
model.add(DenseNet121(include_top=False, pooling='avg', weights='imagenet'))
model.add(Dense(114, activation='softmax'))

# Freeze DenseNet layers
model.layers[0].trainable = False

# Compile model
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Train model
model.fit(
    train_generator,
    validation_data=validation_generator,
    epochs=20)

# Evaluate model on test set
test_loss, test_acc = model.evaluate(test_generator)
print('Test accuracy: {:.2f}%'.format(test_acc * 100))


# In[25]:


#accuracies by each FST
validation_probabilities = model.predict(test_generator)
predicted_labels = np.argmax(validation_probabilities, axis=1)

true_labels = np.array(test_generator.classes)
fitzpatrick_scale_values = np.array(df.loc[test_generator.index_array, 'fitzpatrick_scale'])


# In[43]:


def calculate_accuracy_by_fitzpatrick_scale(predictions, true_labels, fitzpatrick_scale_values):
    accuracies = {}
    for scale_value in np.unique(fitzpatrick_scale_values):
        indices = np.where(fitzpatrick_scale_values == scale_value)
        scale_true_labels = true_labels[indices]
        scale_predictions = predictions[indices]
        correct_predictions = np.sum(scale_true_labels == scale_predictions)
        accuracy = correct_predictions / len(scale_true_labels)
        accuracies[scale_value] = accuracy
    return accuracies


# In[30]:


accuracies_by_fitzpatrick_scale = calculate_accuracy_by_fitzpatrick_scale(predicted_labels, true_labels, fitzpatrick_scale_values)


# In[ ]:


for scale_value, accuracy in accuracies_by_fitzpatrick_scale.items():
    print(f"Accuracy for Fitzpatrick scale {scale_value}: {accuracy:.4f}")

